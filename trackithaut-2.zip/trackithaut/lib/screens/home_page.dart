import 'package:flutter/material.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:logger/logger.dart';

final logger = Logger();

TileLayer get openStreetMapTileLayer => TileLayer(
  urlTemplate: 'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
  userAgentPackageName: 'dev.leaflet.homePage.example',
);

class Professor {
  final String name;
  final String email;

  Professor({required this.name, required this.email});

  factory Professor.fromJson(Map<String, dynamic> json) {
    return Professor(
      name: json['name'] ?? 'Unknown',
      email: json['email'] ?? 'No email',
    );
  }
}

class HomePagee extends StatefulWidget {
  const HomePagee({super.key});
  @override
  State<HomePagee> createState() => _HomePageState();
}

class _HomePageState extends State<HomePagee> {
  List<String> room = [
    '501',
    '502',
    '503',
    '504',
    '505',
    '506',
    '507',
    '508',
    '509',
    '510',
  ];
  List<String> floor = ['1st', '2nd', '3rd', '5th', '6th', '7th'];
  List<String> unibuilding = [
    'St. Joseph Hall Building',
    'Mamerto G. Nepomuceno BUilding',
    'Archbisop Pedro Sanros Building ',
    'St. Joseph Hall Building',
  ];

  int? selectedProfIndex;

  static const double navButtonClosed = 130.0;
  double navButton = navButtonClosed;

  static const double navnextRoomButtonClosed = 65.0;
  double navnextRoomButton = navnextRoomButtonClosed;

  int selectedIndex = 0;
  final PanelController panelController = PanelController();

  final supabase = Supabase.instance.client;
  List<Professor> professors = [];
  String? currentUserEmail; // Store current user's email

  @override
  void initState() {
    super.initState();
    
    // Get current user's email
    currentUserEmail = supabase.auth.currentUser?.email;
    logger.i('Current user email: $currentUserEmail');
    
    fetchProfessors();
  }

  void openPanel(int index) {
    double pos = panelController.panelPosition;

    if (selectedIndex == index) {
      if (pos == 0.0) {
        panelController.animatePanelToPosition(0.5, curve: Curves.easeInOut);
      } else {
        panelController.close();
      }
    } else {
      setState(() {
        selectedIndex = index;
      });

      if (pos == 0.0) {
        panelController.animatePanelToPosition(0.5, curve: Curves.easeInOut);
      }
    }
  }

  Widget topBar() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Container(
              margin: EdgeInsets.only(right: 10),
              height: 50,
              width: double.maxFinite,
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: Color(0xFF550000),
                borderRadius: BorderRadius.all(Radius.circular(30)),
              ),
              child: Expanded(
                child: Container(
                  padding: EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(30)),
                    color: Colors.white,
                  ),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        'HAUtogo',
                        style: TextStyle(
                          color: Color(0xFFEFBF04),
                          fontWeight: FontWeight.w900,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.only(top: 5, left: 5, right: 1, bottom: 5),
              height: 50,
              width: double.maxFinite,
              decoration: BoxDecoration(
                color: Color(0xFF550000),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(5),
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    child: Container(
                      height: 50,
                      margin: EdgeInsets.only(right: 5),
                      alignment: Alignment.center,
                      child: TextField(
                        textAlign: TextAlign.left,
                        style: TextStyle(fontSize: 12),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          hintText: 'Enter Location',
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            borderSide: BorderSide(color: Colors.black),
                          ),
                          border: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.black),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    width: 40,
                    height: 40,
                    margin: EdgeInsets.only(right: 5),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(5),
                          bottomLeft: Radius.circular(20),
                          bottomRight: Radius.circular(20),
                        ),
                      ),
                      child: Stack(
                        alignment: Alignment(1, -1),
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.location_on,
                              size: 20,
                              color: Color(0xFFEFBF04),
                            ),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: Icon(
                              Icons.location_on_outlined,
                              size: 20,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget building() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        height: 150,
        width: 70,
        decoration: BoxDecoration(
          color: Color(0xFF550000),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(3),
            bottomLeft: Radius.circular(15),
            bottomRight: Radius.circular(15),
          ),
        ),
        margin: EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(1),
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12),
                ),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(1);
                },
                child: Text(
                  'SJH',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(2);
                },
                child: Text(
                  'MGN',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 55,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {
                  openPanel(3);
                },
                child: Text(
                  'APS',
                  style: TextStyle(
                    fontSize: 13,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget navNextRoom() {
    return FloatingActionButton.extended(
      backgroundColor: Colors.white,
      onPressed: () {
        openPanel(4);
      },
      label: Text(
        style: TextStyle(
          fontWeight: FontWeight.w900,
          color: Color(0xFFEFBF04),
          fontSize: 15,
        ),
        'Navigate next class',
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(5),
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
    );
  }

  Widget content() {
    return FlutterMap(
      options: MapOptions(
        initialCenter: LatLng(15.132758, 120.589671),
        initialZoom: 17,
        interactionOptions: InteractionOptions(
          flags: ~InteractiveFlag.doubleTapZoom | InteractiveFlag.drag,
        ),
      ),
      children: [openStreetMapTileLayer],
    );
  }

  Future<void> fetchProfessors() async {
    try {
      final response = await supabase
          .from('professors')
          .select();
      
      logger.i('Raw response: $response');
      logger.i('Response type: ${response.runtimeType}');

      setState(() {
        professors = (response as List)
            .map((p) => Professor.fromJson(p as Map<String, dynamic>))
            .where((professor) => professor.email != currentUserEmail) // Filter out current user
            .toList();
      });
      
      logger.i('Professors loaded (excluding current user): ${professors.length}');
    } catch (e) {
      logger.e('Error fetching professors: $e');
    }
  }

  Widget prof(BuildContext context) {
    if (professors.isEmpty) {
      return Padding(
        padding: EdgeInsets.all(20),
        child: Center(
          child: Text(
            'No other professors found',
            style: TextStyle(fontSize: 16, color: Colors.grey),
          ),
        ),
      );
    }
    
    return ListView.builder(
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: professors.length,
      itemBuilder: (context, index) {
        final prof = professors[index];
        return Card(
          margin: EdgeInsets.only(bottom: 10),
          child: ListTile(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  prof.name,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: Color(0xFF550000),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  prof.email,
                  style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                ),
              ],
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
            onTap: () {
              setState(() {
                selectedProfIndex = index;
                selectedIndex = 5;
              });
            },
          ),
        );
      },
    );
  }

  Widget sjh() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image of St. Joseph Hall Building
          Container(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              color: Colors.transparent,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/joseph_hall.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),

          // Building name
          Container(
            margin: EdgeInsets.only(left: 30),
            child: Text(
              'St. Joseph Hall Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          // Professors header
          Container(
            margin: EdgeInsets.only(top: 20),
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment(0, 0),
            child: Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          // Professors list
          Container(margin: EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget mgn() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/mgn.jpg',
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),

          Container(
            margin: EdgeInsets.only(left: 30),
            child: Text(
              'Mamerto G. Nepomuceno Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment(0, 0),
            child: Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget aps() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            width: double.infinity,
            height: 350,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset(
                'assets/images/aps.jpg', 
                width: double.infinity,
                height: double.infinity,
                fit: BoxFit.fill,
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png');
                },
              ),
            ),
          ),

          Container(
            margin: EdgeInsets.only(left: 30),
            child: Text(
              'Archbisop Pedro Sanros Building',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 20),
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment(0, 0),
            child: Text(
              'PROFESSORS',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(margin: EdgeInsets.all(20), child: prof(context)),
        ],
      ),
    );
  }

  Widget navNextRoompanel() {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Color(0xFF550000),
            height: 40,
            width: double.infinity,
            alignment: Alignment.centerLeft,
            padding: EdgeInsets.only(left: 10),
            child: Text(
              'Location:',
              style: TextStyle(
                fontSize: 20,
                color: Color(0xFFEFBF04),
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 40),
            child: Text(
              'Floor: ${floor[2]} floor\nRoom: ${room[2]}\nBuilding: ${unibuilding[2]}',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 119, 119, 119),
            ),
            width: double.infinity,
            height: 280,
            alignment: Alignment.center,
            child: Image.asset(
              'assets/images/myimage.png',
              errorBuilder: (context, error, stackTrace) {
                return Image.asset('assets/images/placeholder.png');
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget navProfpanel(int index) {
    return Container(
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: const Color(0xFF550000),
            height: 60,
            width: double.infinity,
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Professor ${professors[index].name}',
                  style: const TextStyle(
                    fontSize: 20,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  professors[index].email,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.white,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 40),
            child: Text(
              'Floor: ${floor[index]} floor\nRoom: ${room[index]}\nBuilding: ${unibuilding[index]}',
              textAlign: TextAlign.left,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFF550000),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 119, 119, 119),
            ),
            width: double.infinity,
            height: 280,
            alignment: Alignment.center,
            child: Image.asset(
              'assets/images/myimage.png',
              errorBuilder: (context, error, stackTrace) {
                return Image.asset('assets/images/placeholder.png');
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget panelContent() {
    switch (selectedIndex) {
      case 1:
        return sjh();
      case 2:
        return mgn();
      case 3:
        return aps();
      case 4:
        return navNextRoompanel();
      case 5:
        return navProfpanel(selectedProfIndex!);
      default:
        return Text("No content selected");
    }
  }

  Widget buildNavButton(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.white,
      child: Icon(Icons.my_location, color: Color(0xFFEFBF04)),
      onPressed: () {},
    );
  }

  Widget toggleButton() {
    return Stack(
      alignment: Alignment.topCenter,
      children: [
        Container(
          alignment: Alignment.center,
          width: double.maxFinite,
          height: 30,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            color: Color(0xFF550000),
          ),
        ),
        Container(
          alignment: Alignment.center,
          margin: EdgeInsets.all(10),
          width: 50,
          height: 5,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: Color(0xFFEFBF04),
          ),
        ),
      ],
    );
  }

  final ScrollController _controller = ScrollController();

  Widget panelWidget() {
    return Column(
      children: [
        toggleButton(),
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            controller: _controller,
            children: <Widget>[panelContent(), SizedBox(height: 60)],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    double panelHeightOpen = 620;
    final panelHeightClosed = MediaQuery.of(context).size.height * 0;

    return Scaffold(
      body: Stack(
        alignment: Alignment.topCenter,
        children: <Widget>[
          content(),
          Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: 40),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [topBar(), building()],
                ),
              ),
            ],
          ),
          SlidingUpPanel(
            borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
            controller: panelController,
            maxHeight: panelHeightOpen,
            minHeight: panelHeightClosed,
            panelBuilder: (ScrollController sc) {
              return Column(
                children: [
                  toggleButton(),
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.zero,
                      controller: sc,
                      children: <Widget>[panelContent(), SizedBox(height: 60)],
                    ),
                  ),
                ],
              );
            },
            snapPoint: 0.5,
            onPanelSlide: (position) => setState(() {
              double panelMaxScrollExtent = panelHeightOpen;
              navButton =
                  navButtonClosed + (panelMaxScrollExtent - 50) * position;
              navnextRoomButton =
                  navnextRoomButtonClosed +
                  (panelMaxScrollExtent - 50) * position;
            }),
          ),
          Positioned(
            bottom: navButton,
            right: 20,
            child: Column(children: [buildNavButton(context)]),
          ),
          Positioned(
            bottom: navnextRoomButton,
            right: 20,
            child: Column(children: [navNextRoom()]),
          ),
        ],
      ),
    );
  }
}