import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:trackithaut/screens/login.dart';
import 'package:trackithaut/screens/setNewPass.dart';

// ✅ Global navigator key (lets us navigate outside of BuildContext)
final navigatorKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://jhmmrovvjokmebediyzt.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpobW1yb3Z2am9rbWViZWRpeXp0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAxMzUzOTksImV4cCI6MjA3NTcxMTM5OX0.75U7atKYD1CPpZOmp2HsNpjJYEu-Ip1S0YGII875Zls',
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final StreamSubscription<AuthState> _authSub;

  @override
  void initState() {
    super.initState();

    // Listen for auth state changes
    _authSub = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      final event = data.event;
      final session = data.session;
      
      if (event == AuthChangeEvent.passwordRecovery) {
        navigatorKey.currentState?.pushReplacement(
          MaterialPageRoute(
            builder: (_) => SetNewPass(
              email: session?.user.email ?? "",
            ),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _authSub.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey, // ✅ Use global navigator
      home: const Login(),
    );
  }
}