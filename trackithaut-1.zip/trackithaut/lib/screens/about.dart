import 'package:flutter/material.dart';

class About extends StatefulWidget {
  const About({super.key});

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {
  
    Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black))
      ),
      child: Row(

        children: [
          Container(
            alignment: Alignment.centerLeft,
            child: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back)
            ),
          ),
          Container(
            margin: EdgeInsets.all(10),
            alignment: Alignment.center,
            child: Text(
              'About',
              style: TextStyle(
                color: Color(0xFF550000),
                fontSize: 25,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget abtmsg() {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 20),
          child: Text(
            'We are a passionate and innovative team committed to creating digital experiences that make life simpler, more enjoyable, and more productive. Our journey began with a vision to bridge the gap between technology and people, delivering applications and services that are intuitive, reliable, and impactful. Every product we develop is designed with the user in mind, focusing on seamless functionality, aesthetic appeal, and meaningful interaction.',
            
          ),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 20),
          child: Text(
            'Our mission is to empower individuals and organizations to achieve more by providing tools that are not only efficient but also accessible to everyone. We believe in embracing creativity and innovation while maintaining the highest standards of integrity and quality. Collaboration lies at the heart of everything we do; we learn from each other, adapt to change, and continuously improve to stay ahead in a rapidly evolving technological landscape.',
            
          ),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 20),
          child: Text(
            'We also care deeply about community and responsibility. We ensure our solutions respect privacy, encourage responsible usage, and contribute positively to the digital ecosystem. By combining technical expertise, design thinking, and a genuine understanding of user needs, we aim to transform ideas into meaningful experiences that make a difference in the world.',
            
          ),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 20),
          child: Text(
            'At the core of our work is a simple belief: technology should serve people, not the other way around. Through dedication, innovation, and empathy, we strive to build applications that inspire, connect, and empower users everywhere.',
            
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: topBar(context),
        automaticallyImplyLeading: false,
      ),
      body: Container(
        margin: EdgeInsets.all(10),
        child: abtmsg(),
      ),
    );
  }
}