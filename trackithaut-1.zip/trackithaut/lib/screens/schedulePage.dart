import 'package:flutter/material.dart';
import 'package:stroke_text/stroke_text.dart';
import 'package:flutter_timetable/flutter_timetable.dart';

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  State<SchedulePage> createState() => _SchedulePage();
}

class _SchedulePage extends State<SchedulePage> {
  final TimetableController _controller = TimetableController(
    startHour: 6,
    endHour: 21,
    cellHeight: 40,
    initialColumns: 7,
  );

  // static const List<String> yrlvl = ['1ST', '2ND', '3RD', '4TH'];
  // static const List<String> sem = ['FIRST', 'SECOND'];

Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Container(
        margin: EdgeInsets.all(10),
        alignment: Alignment.center,
        child: Text(
          'Schedule',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 25,
            fontWeight: FontWeight.w300,
          ),
        ),
      ),
    );
  }

  Widget grlvl() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        StrokeText(
          text: 'NTH YEAR',
          strokeColor: Colors.black,
          strokeWidth: 2,
          textStyle: TextStyle(
            color: Color(0xFFEFBF04),
            fontSize: 35,
            fontWeight: FontWeight.w900,
          ),
        ),
        Text(
          'nth Semester',
          style: TextStyle(
            color: Colors.black,
            fontSize: 25,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

  Widget sched() {
    return SingleChildScrollView(
      child: FittedBox(
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Color(0xFF550000),
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              DataTable(
                columns: const [
                  DataColumn(
                    label: Center(
                      child: Text(
                        'Class Code',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Center(
                      child: Text(
                        'Subject',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Center(
                      child: Text(
                        'Room',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  DataColumn(
                    label: Center(
                      child: Text(
                        'Instructor',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
                rows: [
                  DataRow(
                    cells: [
                      DataCell(
                        Center(
                          child: Text(
                            '1234',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Example Subject',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'SJH - 501',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Instructor\'s name',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  DataRow(
                    cells: [
                      DataCell(
                        Center(
                          child: Text(
                            '1234',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Example Subject',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'SJH - 501',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Instructor\'s name',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  DataRow(
                    cells: [
                      DataCell(
                        Center(
                          child: Text(
                            '1234',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Example Subject',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'SJH - 501',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Instructor\'s name',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  DataRow(
                    cells: [
                      DataCell(
                        Center(
                          child: Text(
                            '1234',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Example Subject',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'SJH - 501',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Instructor\'s name',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  DataRow(
                    cells: [
                      DataCell(
                        Center(
                          child: Text(
                            '1234',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Example Subject',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'SJH - 501',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Instructor\'s name',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                  DataRow(
                    cells: [
                      DataCell(
                        Center(
                          child: Text(
                            '1234',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Example Subject',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'SJH - 501',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                      DataCell(
                        Center(
                          child: Text(
                            'Instructor\'s name',
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }



  Widget timetable() {
    return Container(
      height: 450, // defines visible timetable height
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black),
        borderRadius: BorderRadius.all(Radius.circular(10))
      ),
      child: Timetable<String>(
        controller: _controller,
        items: [ //dito mga scheds
          TimetableItem<String>(
            DateTime(2025, 10, 13, 9, 0), 
            DateTime(2025, 10, 13, 12, 0),
            data: 'IASEC' 
          )
        ],

        itemBuilder: (item) {
        // Display start time, end time, and data
        String start = '${item.start.hour}:${item.start.minute.toString().padLeft(2, '0')}';
        String end = '${item.end.hour}:${item.end.minute.toString().padLeft(2, '0')}';

        return Container(
          margin: const EdgeInsets.symmetric(vertical: 2),
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: Colors.orange,
            border: Border.all(color: Colors.black, width: .5),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                '$start - $end',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                item.data ?? '',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        );
      },
        
        cellBuilder: (dateTime) => Container(
          decoration: BoxDecoration(
            border: Border.symmetric(vertical: BorderSide(color: Colors.black,width: 0.5),),
          ),
        ),

        // 👇 Header with month + day + date
        headerCellBuilder: (dateTime) {
          // Day abbreviation
          const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
          // Month names
          const months = [
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
          ];

          String day = days[dateTime.weekday - 1];
          String month = months[dateTime.month - 1];
          String dayNumber = dateTime.day.toString();

          return Container(
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.black))
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '$day',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                Text(
                  '$month $dayNumber',
                  style: const TextStyle(
                    fontSize: 11,
                  ),
                ),
              ],
            )
          );
        },

        // Hour labels on the left
        hourLabelBuilder: (time) {
          final hour = time.hour == 12 ? 12 : time.hour % 12;
          final period = time.hour < 12 ? 'AM' : 'PM';
          return Text(
            '$hour $period',
            style: const TextStyle(fontSize: 10, color: Colors.black),
          );
        },

        nowIndicatorColor: Colors.redAccent,
        snapToDay: true,
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: topBar(context)),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            children: [
              grlvl(),
              const SizedBox(height: 10),
              sched(),
              const SizedBox(height: 13),
              timetable(),
              const SizedBox(height: 70),
            ],
          ),
        ),
      ),
    );
  }
}

// static timetable

  // final hours = List.generate(11, (i) => "${7 + i}:00");
  // final days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  // Widget timetable() {
  //   return Container(
  //     margin: const EdgeInsets.only(top: 15),
  //     height: 500, // fixed height instead of Expanded
  //     decoration: BoxDecoration(
  //       borderRadius: BorderRadius.circular(5),
  //     ),
  //     child: Column(
  //       children: [
  //         // Header Row (Days)
  //         Container(
  //           decoration: BoxDecoration(
  //             color: Color(0xFF550000),
  //             border: Border.all(color: Colors.black)
  //           ),
  //           child: Row(
  //             children: [
  //               const SizedBox(width: 60), // space for time column
  //               ...days.map(
  //                 (d) => Expanded(
  //                   child: Container(
  //                     alignment: Alignment.center,
  //                     padding: const EdgeInsets.all(5),
  //                     // decoration: BoxDecoration(
  //                     //   border: Border.all(color: Colors.grey.shade300),
  //                     // ),
  //                     // child: Text(
  //                     //   d,
  //                     //   style: const TextStyle(fontWeight: FontWeight.bold),
  //                     // ),
  //                   ),
  //                 ),
  //               ),
  //             ],
  //           ),
  //         ),

  //         // Scrollable body
  //         Expanded(
  //           child: SingleChildScrollView(
  //             child: Column(
  //               children: hours.map((hour) {
  //                 return Row(
  //                   children: [
  //                     // Hour column
  //                     Container(
  //                       width: 60,
  //                       height: 50,
  //                       alignment: Alignment.center,
  //                       decoration: BoxDecoration(
  //                         border: Border.symmetric(vertical: BorderSide(color: Colors.black)),
  //                       ),
  //                       child: Text(
  //                         hour,
  //                         style: const TextStyle(fontSize: 12),
  //                       ),
  //                     ),
  //                     // Day columns
  //                     ...days.map(
  //                       (d) => Expanded(
  //                         child: Container(
  //                           height: 50,
  //                           decoration: BoxDecoration(
  //                             border: Border.symmetric(vertical: BorderSide(color: Colors.black)),    
  //                           ),
  //                           child: const SizedBox.shrink(),
  //                         ),
  //                       ),
  //                     ),
  //                   ],
  //                 );
  //               }).toList(),
  //             ),
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }


//timetable pero whole year and di sya static, tho pwede sya if uk the whole year sched

// Widget timetable() {
//     return SizedBox(
//       height: 400, // defines visible timetable height
//       child: Timetable<String>(
//         controller: _controller,
//         items: const [],
//         cellBuilder: (dateTime) => Container(
//           decoration: BoxDecoration(
//             border: Border.all(color: Colors.grey.shade300, width: 0.4),
//           ),
//         ),
//         headerCellBuilder: (dateTime) {
//           const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
//           return Center(
//             child: Text(
//               days[dateTime.weekday - 1],
//               style: const TextStyle(
//                 fontWeight: FontWeight.bold,
//                 fontSize: 13,
//               ),
//             ),
//           );
//         },
//         hourLabelBuilder: (time) {
//           final hour = time.hour == 12 ? 12 : time.hour % 12;
//           final period = time.hour < 12 ? 'AM' : 'PM';
//           return Text(
//             '$hour$period',
//             style: const TextStyle(fontSize: 9, color: Colors.black54),
//           );
//         },
//         nowIndicatorColor: Colors.redAccent,
//         snapToDay: true,
//       ),
//     );
//   }