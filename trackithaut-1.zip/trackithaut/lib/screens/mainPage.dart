import 'package:flutter/material.dart';
import 'package:trackithaut/screens/home_page.dart';
import 'package:trackithaut/screens/profilePage.dart';
import 'package:trackithaut/screens/schedulePage.dart';



class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int currentPage = 0;

  final List<Widget> pages = [
    HomePagee(),
    // ProfTrackPage(),
    SchedulePage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          pages[currentPage],
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.only(topLeft: Radius.circular(100)),
                child: BottomNavigationBar(
                  type: BottomNavigationBarType.shifting,
                    showUnselectedLabels: true,
                    unselectedLabelStyle: TextStyle(
                      fontSize: 12,
                      color: Colors.white70
                    ),
                    selectedFontSize: 14,
                    selectedItemColor: Color(0xFFEFBF04),
                    unselectedItemColor: Colors.white70,
                    iconSize: 20,
                    currentIndex: currentPage,
                    onTap: (value) {
                      setState(() {
                        currentPage = value;
                      });
                    },
                    items: [
                      BottomNavigationBarItem(
                        icon: Icon(Icons.home),
                        label: 'Home',
                        backgroundColor: Color(0xFF550000),
                      ),
                      // BottomNavigationBarItem(
                      //   icon: Icon(Icons.person_pin_circle),
                      //   label: 'Tracker',
                      //   backgroundColor: Color(0xFF550000),
                      // ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.schedule),
                        label: 'Schedule',
                        backgroundColor: Color(0xFF550000),
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.person),
                        label: 'Profile',
                        backgroundColor: Color(0xFF550000),
                      ),
                    ]
                  ),
                ),
            ],
          )
        ],
      ),
    );
  }
}