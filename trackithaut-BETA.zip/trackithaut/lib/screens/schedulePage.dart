import 'package:flutter/material.dart';
import 'homePage.dart';
import 'package:stroke_text/stroke_text.dart';

class SchedulePage extends StatelessWidget{
  const SchedulePage({super.key});

  Widget topBar(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(0),
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  );
                },
                icon: Icon(Icons.arrow_back),
              ),
            ),
          Align(
            alignment: Alignment.center,
            child: Text(
              'Schedule',
              style: TextStyle(
                color: Color(0xFF550000),
                fontSize: 25,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget grlvl() {
    return Column(
      children: [
        StrokeText(text: 'NTH YEAR',),
        StrokeText(text: 'nth Semester',)
      ],
    );
  }

  Widget sched() {
    return Container(

    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: topBar(context),
      ),
      body: Text('Schedule Page'),
    );
  }
}
