import 'package:flutter/material.dart';

class ChangePass extends StatelessWidget{
  const ChangePass({super.key});

  @override
  Widget build(BuildContext context) {
    return Align();
  }
}
