import 'package:flutter/material.dart';
import 'homePage.dart';

class ProfTrackPage extends StatelessWidget{
  const ProfTrackPage({super.key});

  Widget topBar(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(0),
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  );
                },
                icon: Icon(Icons.arrow_back),
              ),
            ),
          Align(
            alignment: Alignment.center,
            child: Text(
              'Tracker',
              style: TextStyle(
                color: Color(0xFF550000),
                fontSize: 25,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildingChoice() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded(
              child: Card(
                child: ListTile(
                  title: Text('SJH'),
                ),
              ),
            ),
            Expanded(
              child: Card(
                child: ListTile(
                  title: Text('MGN'),
                ),
              ),
            ),
            Expanded(
              child: Card(
                child: ListTile(
                  title: Text('APS'),
                ),
              ),
            ),
          ],
        ),
        Container(
              decoration: BoxDecoration(
                color: Colors.grey
              ),
              width: double.infinity,
              height: 165,
              alignment: Alignment.center,
              child: Image.asset(
                'assets/images/myimage.png',
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png'); // fallback
                },
              ),
            ),
        Card(
          child: ListTile(
            title: Text('Teacher name'),
          ),
        ),
        Card(
          child: ListTile(
            title: Text('Teacher name'),
          ),
        ),
        Card(
          child: ListTile(
            title: Text('Teacher name'),
          ),
        ),
        Card(
          child: ListTile(
            title: Text('Teacher name'),
          ),
        ),
        Card(
          child: ListTile(
            title: Text('Teacher name'),
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: topBar(context),
      ),
      body: Container(
        decoration: BoxDecoration(color: Colors.blueGrey),
        child: buildingChoice(),
      )
    );
  }
}
