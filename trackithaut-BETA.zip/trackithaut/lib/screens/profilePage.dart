import 'package:flutter/material.dart';
import 'package:trackithaut/screens/login.dart';
// import 'login.dart';
import 'edit_profile.dart';
import 'homePage.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  Widget topBar(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(0),
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HomePage()),
                  );
                },
                icon: Icon(Icons.arrow_back),
              ),
            ),
          Align(
            alignment: Alignment.center,
            child: Text(
              'Profile',
              style: TextStyle(
                color: Color(0xFF550000),
                fontSize: 25,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget profile() {
    return Column(
      children: [
        Icon(Icons.account_circle, size: 90,),
        Text(
          'Felix Fox',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 20,
            fontWeight: FontWeight.w900
          ),
        ),
        Text(
          'ffox@student.hau.edu.ph',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 12,
            fontWeight: FontWeight.w500,
            decoration: TextDecoration.underline
          ),
        )
      ],
    );
  }

  Widget settings(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: EdgeInsets.only(
          top: 30,
          left: 60,
          right: 60,
          bottom: 10
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.edit),
                ),
                title: Text('Edit Profile'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EditProfile())
                  );
                },
              ),
            ),
            Container(
              margin: EdgeInsets.only(
                top: 10,
                left: 10,
                bottom: 10
              ),
              child: Text(
                'General Settings',
                style: TextStyle(
                  fontSize: 18
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.info),
                ),
                title: Text('About'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EditProfile())
                  );
                },
              ),
            ),
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.rule),
                ),
                title: Text('Terms & Conditions'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EditProfile())
                  );
                },
              ),
            ),
            Card(
              child: ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.privacy_tip),
                ),
                title: Text('Privacy Settings'),
                trailing: Icon(Icons.arrow_forward),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => EditProfile())
                  );
                },
              ),
            ),
            SizedBox(
              width: double.maxFinite,
              height: 40,
              child: FilledButton(
                onPressed: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const Login()
                  ),
                  (Route<dynamic> route) => false,
                  );
                },
                style: FilledButton.styleFrom(
                  backgroundColor: Color(0xFF550000),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadiusGeometry.circular(8)
                  ),
                  side: BorderSide(color: Colors.black)
                ),
                child: Text('Log Out', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),)
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 60,
        title: Container(
          margin: EdgeInsets.only(top: 40),
          child: topBar(context),
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(
          bottom: 200
        ),
        child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          profile(),
          settings(context),
        ],
      ),
      )
    );
  }
}
