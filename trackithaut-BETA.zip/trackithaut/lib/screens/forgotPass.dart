import 'package:flutter/material.dart';

class ForgotPass extends StatelessWidget{
  const ForgotPass({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
