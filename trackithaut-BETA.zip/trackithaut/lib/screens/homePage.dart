import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:trackithaut/screens/proftrackpage.dart';
import 'schedulePage.dart';
import 'profilePage.dart';
import 'package:stroke_text/stroke_text.dart';

TileLayer get openStreetMapTileLayer =>  TileLayer(
  urlTemplate: 'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
  // userAgentPackageName: 'com.homePage.flutter',
  userAgentPackageName: 'dev.leaflet.homePage.example',
);

class HomePage extends StatelessWidget{
  const HomePage({super.key});

  Widget content() {
    return FlutterMap(
      options: MapOptions(
        initialCenter: LatLng(15.132758, 120.589671),
        initialZoom: 17,
        interactionOptions: InteractionOptions(
          flags: ~InteractiveFlag.doubleTapZoom | InteractiveFlag.drag
        )
      ),
      children: [
        openStreetMapTileLayer,
      ]
    );
  }

  Widget topBar() {
    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: 50,
                width: 100,
                decoration: BoxDecoration(
                  color: Color(0xFF550000),
                  borderRadius: BorderRadius.all(Radius.circular(30)),
                ),
              ),
              Container(
                padding: EdgeInsets.only(
                  top: 5,
                  left: 5,
                  right: 1,
                  bottom: 5
                ),
                height: 50,
                width: 200,
                decoration: BoxDecoration(
                  color: Color(0xFF550000),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(30),
                    topRight: Radius.circular(5),
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30)
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        // width: 142,
                        height: 50,
                        alignment: Alignment.center,
                        child: TextField(
                          textAlign: TextAlign.left,
                          style: TextStyle(fontSize: 12),
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.white,
                            hintText: 'Enter Location',
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(20)),
                              borderSide: BorderSide(color: Colors.black)
                            ),
                            border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.black),
                              borderRadius: BorderRadius.all(Radius.circular(20))
                            ),
                          ),
                        ),
                      ), 
                    ),
                    Container(
                      alignment: Alignment.center,
                      width: 48,
                      height: 40,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(5),
                            bottomLeft: Radius.circular(20),
                            bottomRight: Radius.circular(20)
                          )
                        ),
                        child: Stack(
                          alignment: Alignment(1, -1),
                          children: [
                            IconButton(
                              onPressed: () {},
                              icon: Icon(
                                Icons.location_on,
                                size: 20,
                                color: Color(0xFFEFBF04),
                              ),
                            ),
                            IconButton(
                              onPressed: () {},
                              icon: Icon(
                                Icons.location_on_outlined,
                                size: 20,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        )
                      ),
                    ),
                  ],
                )
              ),
            ],
          ),
    );
    // return Row(
    //   mainAxisAlignment: MainAxisAlignment.start,
    //   children: [
    //     Flexible(
    //       child: Container(
    //         height: 50,
    //       margin: EdgeInsets.all(10),
    //       color: Colors.transparent,
    //       alignment: Alignment.center,
    //       width: double.infinity,
    //       child: Row(
    //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //         children: [
    //           Container(
    //             height: 50,
    //             width: 100,
    //             decoration: BoxDecoration(
    //               color: Color(0xFF550000),
    //               borderRadius: BorderRadius.all(Radius.circular(30)),
    //             ),
    //           ),
    //           Container(
    //             padding: EdgeInsets.only(
    //               top: 5,
    //               left: 5,
    //               right: 1,
    //               bottom: 5
    //             ),
    //             height: 50,
    //             width: 200,
    //             decoration: BoxDecoration(
    //               color: Color(0xFF550000),
    //               borderRadius: BorderRadius.only(
    //                 topLeft: Radius.circular(30),
    //                 topRight: Radius.circular(5),
    //                 bottomLeft: Radius.circular(30),
    //                 bottomRight: Radius.circular(30)
    //               ),
    //             ),
    //             child: Row(
    //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //               children: <Widget>[
    //                 Expanded(
    //                   child: Container(
    //                     // width: 142,
    //                     height: 50,
    //                     alignment: Alignment.center,
    //                     child: TextField(
    //                       textAlign: TextAlign.left,
    //                       style: TextStyle(fontSize: 12),
    //                       decoration: InputDecoration(
    //                         filled: true,
    //                         fillColor: Colors.white,
    //                         hintText: 'Enter Location',
    //                         focusedBorder: OutlineInputBorder(
    //                           borderRadius: BorderRadius.all(Radius.circular(20)),
    //                           borderSide: BorderSide(color: Colors.black)
    //                         ),
    //                         border: OutlineInputBorder(
    //                           borderSide: BorderSide(color: Colors.black),
    //                           borderRadius: BorderRadius.all(Radius.circular(20))
    //                         ),
    //                       ),
    //                     ),
    //                   ), 
    //                 ),
    //                 Container(
    //                   alignment: Alignment.center,
    //                   width: 48,
    //                   height: 40,
    //                   child: Container(
    //                     decoration: BoxDecoration(
    //                       color: Colors.white,
    //                       borderRadius: BorderRadius.only(
    //                         topLeft: Radius.circular(20),
    //                         topRight: Radius.circular(5),
    //                         bottomLeft: Radius.circular(20),
    //                         bottomRight: Radius.circular(20)
    //                       )
    //                     ),
    //                     child: Stack(
    //                       alignment: Alignment(1, -1),
    //                       children: [
    //                         IconButton(
    //                           onPressed: () {},
    //                           icon: Icon(
    //                             Icons.location_on,
    //                             size: 20,
    //                             color: Color(0xFFEFBF04),
    //                           ),
    //                         ),
    //                         IconButton(
    //                           onPressed: () {},
    //                           icon: Icon(
    //                             Icons.location_on_outlined,
    //                             size: 20,
    //                             color: Colors.black,
    //                           ),
    //                         ),
    //                       ],
    //                     )
    //                   ),
    //                 ),
    //               ],
    //             )
    //           ),
    //         ],
    //       ),
    //     ), 
    //     )
    //   ]
    // );
  }

  Widget building() {
    return Align(
      alignment: Alignment.topLeft,
      child: Container(
        height: 150,
        width: 60,
        decoration: BoxDecoration(
          color: Color(0xFF550000),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(3),
            bottomLeft: Radius.circular(15),
            bottomRight: Radius.circular(15)
          )
        ),
        margin: EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 45,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(1),
                  bottomLeft: Radius.circular(12),
                  bottomRight: Radius.circular(12)
                )
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {}, 
                child: StrokeText(
                  strokeColor: Colors.black,
                  strokeWidth: 4,
                  text:
                  'SJH',
                  textStyle: TextStyle(
                    fontSize: 11,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900
                  ),
                )
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 45,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12)
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {}, 
                child: StrokeText(
                  strokeColor: Colors.black,
                  strokeWidth: 4,
                  text:
                  'MGN',
                  textStyle: TextStyle(
                    fontSize: 9,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900
                  ),
                )
              ),
            ),
            Container(
              padding: EdgeInsets.zero,
              height: 40,
              width: 45,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12)
              ),
              alignment: Alignment.center,
              child: TextButton(
                onPressed: () {}, 
                child: StrokeText(
                  strokeColor: Colors.black,
                  strokeWidth: 4,
                  text:
                  'APS',
                  textStyle: TextStyle(
                    fontSize: 10,
                    color: Color(0xFFEFBF04),
                    fontWeight: FontWeight.w900
                  ),
                )
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget maxButton(BuildContext context) {
    return Align(
      alignment: Alignment.bottomLeft,
      child: Container(
        width: 30,
        height: 30,
        margin: EdgeInsets.only(
          left: 20,
          bottom: 10
        ),
        padding: EdgeInsets.all(5),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Color(0xFF550000),
              spreadRadius: 10,
              blurRadius: 0
            )
          ],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(5),
            bottomLeft: Radius.circular(30),
            bottomRight: Radius.circular(30)
          )
        ),
        child: IconButton(
          padding: EdgeInsets.all(0),
          constraints: BoxConstraints(),
          onPressed: () {
            Navigator.push(
              context, 
              MaterialPageRoute(
                builder: (context) => ProfTrackPage()
              )
            );
          },
          icon: Icon(
            Icons.fullscreen, 
            size: 20, 
            color: Color(0xFFEFBF04),
          )
        ),
      ),
    );
  }

  Widget allocation() {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        padding: EdgeInsets.all(10),
        width: double.infinity,
        margin: EdgeInsets.all(10),
        height: 238,
        decoration: BoxDecoration(
          color: Color(0xFF550000),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25),
            topRight: Radius.circular(5),
            bottomLeft: Radius.circular(25),
            bottomRight: Radius.circular(25)
          )
        ),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white
              ),
              width: double.infinity,
              height: 165,
              alignment: Alignment.center,
              child: Image.asset(
                'assets/images/myimage.png',
                errorBuilder: (context, error, stackTrace) {
                  return Image.asset('assets/images/placeholder.png'); // fallback
                },
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 5),
              width: double.infinity,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Location Place Holder',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFFEFBF04),
                      ),
                    ),
                  ),
                  FilledButton(
                    onPressed: () {},
                    style: FilledButton.styleFrom(
                      backgroundColor: Color(0xFFEFBF04),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)
                      )
                    ),
                    child: Text(
                      'Locate',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ) 
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          content(),
          Container(
            margin: EdgeInsets.only(top: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                topBar(),
                building(),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(bottom: 55),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                  maxButton(context),
                  allocation()
              ],
            ),
          )
        ],
      ),
    );
  }
}


// appBar: AppBar(
      //   automaticallyImplyLeading: false,
      //   toolbarHeight: 65,
      //   title: Container(
      //     color: Colors.transparent,
      //     alignment: Alignment.center,
      //     width: double.infinity,
      //     child: Row(
      //       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      //       children: [
      //         Container(
      //           height: 50,
      //           width: 50,
      //           decoration: BoxDecoration(
      //             color: Color(0xFF550000),
      //             borderRadius: BorderRadius.all(Radius.circular(30)),
      //           ),
      //         ),
      //         Container(
      //           padding: EdgeInsets.all(5),
      //           height: 50,
      //           width: 250,
      //           decoration: BoxDecoration(
      //             color: Color(0xFF550000),
      //             borderRadius: BorderRadius.only(
      //               topLeft: Radius.circular(30),
      //               topRight: Radius.circular(5),
      //               bottomLeft: Radius.circular(30),
      //               bottomRight: Radius.circular(20)
      //             ),
      //           ),
      //           child: Row(
      //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //             children: <Widget>[
      //               Container(
      //                 alignment: Alignment.center,
      //                 width: 58,
      //                 height: 50,
      //                 child: Container(
      //                   decoration: BoxDecoration(
      //                     color: Colors.white,
      //                     borderRadius: BorderRadius.all(Radius.circular(30))
      //                   ),
      //                   child: Stack(
      //                     alignment: Alignment(1, -1),
      //                     children: [
      //                       IconButton(
      //                         onPressed: () {},
      //                         icon: Icon(
      //                           Icons.location_on,
      //                           size: 20,
      //                           color: Color(0xFFEFBF04),
      //                         ),
      //                       ),
      //                       IconButton(
      //                         onPressed: () {},
      //                         icon: Icon(
      //                           Icons.location_on_outlined,
      //                           size: 20,
      //                           color: Colors.black,
      //                         ),
      //                       ),
      //                     ],
      //                   )
      //                 ),
      //               ),
      //               Container(
      //                 width: 180,
      //                 height: 50,
      //                 alignment: Alignment.center,
      //                 child: TextField(
      //                   textAlign: TextAlign.left,
      //                   style: TextStyle(fontSize: 12),
      //                   decoration: InputDecoration(
      //                     filled: true,
      //                     fillColor: Colors.white,
      //                     hintText: 'Enter Location',
      //                     focusedBorder: OutlineInputBorder(
      //                       borderRadius: BorderRadius.only(
      //                         topLeft: Radius.circular(20),
      //                         topRight: Radius.circular(5),
      //                         bottomLeft: Radius.circular(20),
      //                         bottomRight: Radius.circular(20)
      //                       ),
      //                       borderSide: BorderSide(color: Colors.black)
      //                     ),
      //                     border: OutlineInputBorder(
      //                       borderSide: BorderSide(color: Colors.black),
      //                       borderRadius: BorderRadius.only(
      //                         topLeft: Radius.circular(20),
      //                         topRight: Radius.circular(5),
      //                         bottomLeft: Radius.circular(20),
      //                         bottomRight: Radius.circular(20)
      //                       ),
      //                     ),
      //                   ),
      //                 ),
      //               ),
      //             ],
      //           )
      //         ),
      //       ],
      //     ),
      //   ),
      // ),