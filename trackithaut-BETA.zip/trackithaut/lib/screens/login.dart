import 'package:flutter/material.dart';
import 'package:trackithaut/screens/mainPage.dart';
import 'homePage.dart';
// import 'changePass.dart';
import 'forgotPass.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Stack(
        children: [
          Stack(
            children: [
              Image.asset(
                "assets/images/loginbg.jpg",
                height: double.maxFinite,
                fit: BoxFit.cover,
              ),
              Align(
                alignment: Alignment(0, -0.6),
                child: Image.asset(
                  "assets/images/logo.png",
                  height: 130,
                  width: 130,
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.all(50),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color(0xFF550000),
                    spreadRadius: 10,
                    blurRadius: 0,
                  ),
                  BoxShadow(
                    color: Color(0xFFEFBF04),
                    spreadRadius: 5,
                    blurRadius: 0,
                  )
                ],
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(120),
                  topLeft: Radius.circular(30),
                ),
              ),
              width: double.infinity,
              height: 490,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    margin: EdgeInsets.only(bottom: 25),
                    child: Text('Log In',
                      style: TextStyle(fontSize: 50, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 15),
                    width: 230,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Email', style: TextStyle(fontWeight: FontWeight.bold),),
                        TextField(
                          maxLines: null,
                          minLines: 1,
                          style: TextStyle(fontSize: 15),
                          decoration: const InputDecoration(
                            filled: true,
                            fillColor: Color(0xFFDFDFDF),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(8)),
                              borderSide: BorderSide(
                                color: Colors.black
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(8)),
                              borderSide: BorderSide(color: Colors.black)
                            ),
                            hintText: 'Enter student email',
                          ),
                        ),
                      ],
                    )
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 10),
                    width: 230,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Password', style: TextStyle(fontWeight: FontWeight.bold),),
                        TextField(
                          style: TextStyle(fontSize: 15),
                          decoration: const InputDecoration(
                            filled: true,
                            fillColor: Color(0xFFDFDFDF),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(8)),
                              borderSide: BorderSide(color: Colors.black)
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(8)),
                              borderSide: BorderSide(color: Colors.black)
                            ),
                            hintText: 'Enter password',
                          ),
                        ),
                      ],
                    )
                  ),
                  SizedBox(
                    width: 230,
                    height: 40,
                    child: FilledButton(
                    onPressed: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const MainPage()
                        ),
                        (Route<dynamic> route) => false,
                      );
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: Color(0xFF550000),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadiusGeometry.circular(8)
                      ),
                      side: BorderSide(color: Colors.black)
                    ),
                    child: Text('Log In', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),)
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.all(10),
                    height: 50,
                    child: TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ForgotPass()
                          )
                        );
                      },
                      child: Text("Forgot Password?")
                      ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    ); 
  }
}