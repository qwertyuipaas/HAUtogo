import 'package:flutter/material.dart';
import 'package:trackithaut/screens/login.dart';
// import 'package:trackithaut/screens/loginPage.dart';
// import 'package:trackithaut/screens/homePage.dart';

void main () => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Login(),
      ),
    );
  }
}



