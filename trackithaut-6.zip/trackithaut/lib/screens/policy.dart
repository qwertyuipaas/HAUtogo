import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Policy extends StatefulWidget {
  const Policy({super.key});

  @override
  State<Policy> createState() => _PolicyState();
}

class _PolicyState extends State<Policy> {
  bool isAgreed = false;

  Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black))
      ),
      child: Row(

        children: [
          Container(
            alignment: Alignment.centerLeft,
            child: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back)
            ),
          ),
          Container(
            margin: EdgeInsets.all(10),
            alignment: Alignment.center,
            child: Text(
              'Terms & Conditions',
              style: TextStyle(
                color: Color(0xFF550000),
                fontSize: 25,
                fontWeight: FontWeight.w300,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget terms() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 20),
          child: Text('By using this app/service, you agree to the following terms and conditions. You acknowledge that all information provided by you is accurate and truthful. You agree to use this app responsibly, respecting all applicable laws and regulations. You understand that the content, features, and services provided are for personal and non-commercial use unless otherwise stated. You accept that the app/service owner is not liable for any losses, damages, or interruptions that may occur from using this app/service.'),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 20),
          child: Text(
            'By agreeing to these terms, you consent to:',
            style: TextStyle(fontWeight: FontWeight.w900),
          ),
        ),
        Container(
          margin: EdgeInsets.only(left: 20),
          child: Column(
            children: [
              Text('• Using the app/service in accordance with applicable laws.'),
              Text('• Not attempting to hack, modify, or misuse the app/service.'),
              Text('• Receiving notifications, updates, or promotional messages related to the service.'),
              Text('• Allowing the app/service to collect necessary data to provide and improve functionality.'),
              Text('• Accepting that the app/service owner is not responsible for any direct or indirect damages resulting from the use of the app/service.'),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: 40),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Checkbox(
                value: isAgreed,
                onChanged: (bool? value) {
                  setState(() {
                    isAgreed = value ?? false;
                  });
                },
              ),
              Expanded(
                child: Text(
                  "I have read and agree to the Terms and Conditions.",
                  style: TextStyle(fontSize: 14),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 20),
        Container(
          margin: EdgeInsets.only(bottom: 20),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Color(0xFF550000),
            borderRadius: BorderRadius.all(Radius.circular(30))
          ),
          child: TextButton(
            onPressed: isAgreed ? () {
              Navigator.pop(context);
            } : SystemNavigator.pop,
            child: Text(
              "Continue",
              style: TextStyle(color: Colors.white),
            ),
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: topBar(context),
        automaticallyImplyLeading: false,
      ),
      body: Container(
        margin: EdgeInsets.all(10),
        child: Container(
          margin: EdgeInsets.all(10),
          child: terms(),
        ),
      ),
    );
  }
}