import 'package:flutter/material.dart';
import 'package:trackithaut/screens/successPassUpd.dart';

class ChangePass extends StatefulWidget {
  const ChangePass({super.key});

  @override
  State<ChangePass> createState() => _ChangePass();
}

class _ChangePass extends State<ChangePass> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController currentPassController = TextEditingController();
  final TextEditingController newPassController = TextEditingController();
  final TextEditingController confirmPassController = TextEditingController();

  var obscureText1 = true;
  var obscureText2 = true;
  var obscureText3 = true;

  Widget newPass(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 10, bottom: 10),
            child: const Text(
              'Change current password',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
          ),
          const Text(
            'Change your current password. Ensure it differs from previous ones for security',
            style: TextStyle(fontWeight: FontWeight.normal, color: Colors.grey),
          ),

          // Current password
          const SizedBox(height: 15),
          const Text("Current Password", style: TextStyle(fontWeight: FontWeight.bold)),
          TextFormField(
            controller: currentPassController,
            obscureText: obscureText1,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Enter your current password",
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.black)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.black)),
              suffixIcon: GestureDetector(
                onTap: () {
                  setState(() {
                    obscureText1 = !obscureText1;
                  });
                },
                child: Icon(
                  obscureText1 ? Icons.visibility_off : Icons.visibility,
                  color: obscureText1 ? Colors.grey : const Color(0xFF550000),
                ),
              ),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return "Please enter your current password";
              }
              return null;
            },
          ),

          // New password
          const SizedBox(height: 15),
          const Text("New Password", style: TextStyle(fontWeight: FontWeight.bold)),
          TextFormField(
            controller: newPassController,
            obscureText: obscureText2,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Enter your new password",
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.black)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.black)),
              suffixIcon: GestureDetector(
                onTap: () {
                  setState(() {
                    obscureText2 = !obscureText2;
                  });
                },
                child: Icon(
                  obscureText2 ? Icons.visibility_off : Icons.visibility,
                  color: obscureText2 ? Colors.grey : const Color(0xFF550000),
                ),
              ),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return "Please enter a new password";
              } else if (value.length < 6) {
                return "Password must be at least 6 characters long";
              }
              return null;
            },
          ),

          // Confirm password
          const SizedBox(height: 15),
          const Text("Confirm Password", style: TextStyle(fontWeight: FontWeight.bold)),
          TextFormField(
            controller: confirmPassController,
            obscureText: obscureText3,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              hintText: "Re-enter password",
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.black)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Colors.black)),
              suffixIcon: GestureDetector(
                onTap: () {
                  setState(() {
                    obscureText3 = !obscureText3;
                  });
                },
                child: Icon(
                  obscureText3 ? Icons.visibility_off : Icons.visibility,
                  color: obscureText3 ? Colors.grey : const Color(0xFF550000),
                ),
              ),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return "Please confirm your new password";
              } else if (value != newPassController.text) {
                return "Passwords do not match";
              }
              return null;
            },
          ),

          // Update button
          Container(
            height: 50,
            width: double.infinity,
            margin: const EdgeInsets.only(top: 20),
            child: FilledButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  // If all checks pass, proceed
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (context) => const SuccessPassUpd()),
                    (Route<dynamic> route) => false,
                  );
                }
              },
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF550000),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text(
                'Update Password',
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        child: newPass(context),
      ),
    );
  }
}
