import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:logger/logger.dart';

final logger = Logger();

// 1. SCHEDULE DATA MODEL
class Schedule {
  final String id;
  final String professorEmail;
  final String subjectCode;
  final String subjectName;
  final String room;
  final String building;
  final String floor;
  final int dayOfWeek; // 1=Monday, 6=Saturday
  final TimeOfDay startTime;
  final TimeOfDay endTime;

  Schedule({
    required this.id,
    required this.professorEmail,
    required this.subjectCode,
    required this.subjectName,
    required this.room,
    required this.building,
    required this.floor,
    required this.dayOfWeek,
    required this.startTime,
    required this.endTime,
  });

  factory Schedule.fromJson(Map<String, dynamic> json) {
  TimeOfDay parseTime(String timeString) {
    final parts = timeString.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1].split('.').first);
    return TimeOfDay(hour: hour, minute: minute);
  }

  // Determine whether email is under professor_id or student_id
  String email = '';
  if (json.containsKey('professor_id') && json['professor_id'] != null) {
    // professor join shape: { ..., "professor_id": { "email": "x@..." }, ...}
    try {
      email = (json['professor_id']['email'] as String?) ?? '';
    } catch (_) {
      email = '';
    }
  } else if (json.containsKey('student_id') && json['student_id'] != null) {
    // student join shape: { ..., "student_id": { "email": "x@..." }, ...}
    try {
      email = (json['student_id']['email'] as String?) ?? '';
    } catch (_) {
      email = '';
    }
  } else if (json.containsKey('email') && json['email'] != null) {
    // fallback if the API returned email at top-level
    email = json['email'] as String;
  }

  return Schedule(
    id: json['id'].toString(),
    professorEmail: email, // reused field — contains student's email if student schedule
    subjectCode: json['subject_code'] as String,
    subjectName: json['subject_name'] as String,
    room: json['room'] as String,
    building: json['building'] as String,
    floor: json['floor'] as String,
    dayOfWeek: json['day_of_week'] as int,
    startTime: parseTime(json['start_time'] as String),
    endTime: parseTime(json['end_time'] as String),
  );
}

}

class SchedulePage extends StatefulWidget {
  const SchedulePage({super.key});

  @override
  State<SchedulePage> createState() => _SchedulePage();
}

class _SchedulePage extends State<SchedulePage> {
  List<Schedule> _schedules = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchSchedules();
  }

Future<void> _fetchSchedules() async {
  setState(() {
    _isLoading = true;
    _error = null;
  });

  final currentUserEmail = Supabase.instance.client.auth.currentUser?.email;

  if (currentUserEmail == null) {
    setState(() {
      _error = 'Please log in to view your schedule.';
      _schedules = [];
      _isLoading = false;
    });
    return;
  }

  try {
    // 1) Try professor schedules from `schedules` table
    final profResponse = await Supabase.instance.client
        .from('schedules')
        .select('*, professor_id!inner(email)')
        .eq('professor_id.email', currentUserEmail)
        .order('day_of_week')
        .order('start_time');

    final profList = (profResponse as List).map((e) => e as Map<String, dynamic>).toList();

    if (profList.isNotEmpty) {
      final schedules = profList.map((json) => Schedule.fromJson(json)).toList();
      setState(() {
        _schedules = schedules;
        _isLoading = false;
      });
      return;
    }

    // 2) If no professor schedules found, try student schedules
    final studResponse = await Supabase.instance.client
        .from('student_schedules')
        .select('*, student_id!inner(email)')
        .eq('student_id.email', currentUserEmail)
        .order('day_of_week')
        .order('start_time');

    final studList = (studResponse as List).map((e) => e as Map<String, dynamic>).toList();

    if (studList.isNotEmpty) {
      final schedules = studList.map((json) => Schedule.fromJson(json)).toList();
      setState(() {
        _schedules = schedules;
        _isLoading = false;
      });
      return;
    }

    // 3) Nothing found for either role
    setState(() {
      _schedules = [];
      _error = 'No schedules found for this account.';
      _isLoading = false;
    });
  } on PostgrestException catch (e) {
    setState(() {
      _error = 'Database Error: ${e.message}';
      _isLoading = false;
    });
  } catch (e) {
    setState(() {
      _error = 'An unexpected error occurred: $e';
      _isLoading = false;
    });
  }
}


  Widget topBar(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.black, width: 1)),
      ),
      child: Container(
        margin: const EdgeInsets.all(10),
        alignment: Alignment.center,
        child: const Text(
          'Schedule',
          style: TextStyle(
            color: Color(0xFF550000),
            fontSize: 25,
            fontWeight: FontWeight.w300,
          ),
        ),
      ),
    );
  }

  Widget grlvl() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Work Schedule',
          style: TextStyle(
            color: Colors.black,
            fontSize: 25,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    );
  }

Widget timetable() {
  if (_isLoading) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.only(top: 50.0),
        child: CircularProgressIndicator(color: Color(0xFF550000)),
      ),
    );
  }

  if (_error != null) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          _error!,
          style: const TextStyle(color: Colors.red),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  if (_schedules.isEmpty) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.only(top: 50.0),
        child: Text(
          'No schedules found for this professor.',
          style: TextStyle(
            fontSize: 18,
            color: Color(0xFF550000),
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const startHour = 7;
  const endHour = 20;
  const cellHeight = 80.0;
  const cellWidth = 120.0;

  return Container(
    decoration: BoxDecoration(
      border: Border.all(color: Colors.grey.shade400),
    ),
    height: MediaQuery.of(context).size.height * 0.7,
    child: SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Row(
      children: [
        // ⏰ Fixed time column
        Column(
          children: [
            Container(
              height: 40,
              width: 60,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFF550000),
                border: Border.all(color: Colors.black, width: 0.5),
              ),
              child: const Text(
                'Time',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            for (int hour = startHour; hour <= endHour; hour++)
              Container(
                height: cellHeight,
                width: 60,
                alignment: Alignment.topCenter,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300, width: 0.5),
                  color: Colors.white,
                ),
                child: Text(
                  '${hour > 12 ? hour - 12 : hour} ${hour < 12 ? "AM" : "PM"}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: Color(0xFF550000),
                  ),
                ),
              ),
          ],
        ),

        // 📅 Scrollable schedule grid (Mon–Sat)
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: List.generate(days.length, (dayIndex) {
                final daySchedules = _schedules
                    .where((s) => s.dayOfWeek == dayIndex + 1)
                    .toList();

                return Column(
                  children: [
                    // Header
                    Container(
                      height: 40,
                      width: cellWidth,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFBF04),
                        border: Border.all(color: Colors.black, width: 0.5),
                      ),
                      child: Text(
                        days[dayIndex],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          color: Color(0xFF550000),
                        ),
                      ),
                    ),

                    // Schedule grid
                    Stack(
                      children: [
                        Column(
                          children: List.generate(
                            endHour - startHour + 1,
                            (index) => Container(
                              height: cellHeight,
                              width: cellWidth,
                              decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.grey.shade300, width: 0.5),
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        // Schedule blocks
                        ...daySchedules.map((schedule) {
                          final start = schedule.startTime.hour +
                              (schedule.startTime.minute / 60);
                          final end =
                              schedule.endTime.hour + (schedule.endTime.minute / 60);
                          final topOffset =
                              (start - startHour) * cellHeight; // pixels from top
                          final height = (end - start) * cellHeight;

                          return Positioned(
                            top: topOffset,
                            left: 0,
                            right: 0,
                            height: height,
                            child: Container(
                              margin: const EdgeInsets.all(2),
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEFBF04),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: Colors.black, width: 0.5),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    schedule.subjectCode,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                      color: Color(0xFF550000),
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    schedule.subjectName,
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF550000),
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 2,
                                  ),
                                  Text(
                                    '${schedule.room} (${schedule.building}/${schedule.floor})',
                                    style: const TextStyle(
                                      fontSize: 9,
                                      color: Color(0xFF550000),
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Text(
                                    '${schedule.startTime.format(context)} - ${schedule.endTime.format(context)}',
                                    style: const TextStyle(
                                      fontSize: 9,
                                      color: Color(0xFF550000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ],
                    ),
                  ],
                );
              }),
            ),
          ),
        ),
      ],
    ),
    )
  );
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            topBar(context),
            const SizedBox(height: 10),
            grlvl(),
            const SizedBox(height: 10),
            timetable(),
          ],
        ),
      ),
    );
  }
}
